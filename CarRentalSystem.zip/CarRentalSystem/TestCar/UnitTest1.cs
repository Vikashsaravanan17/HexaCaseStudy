﻿using NUnit.Framework;
using System;
using System.Linq;
using CarRentalSystem.dao;
using CarRentalSystem.entity;
using CarRentalSystem.myexceptions;

namespace CarRentalSystem.Tests
{
    public class CarLeaseRepositoryTests
    {
        private ICarLeaseRepository repo;

        [SetUp]
        public void Setup()
        {
            repo = new CarLeaseRepositoryImpl();
        }

        [Test]
        public void Test_CarCreatedSuccessfully()
        {
            int newCarId = new Random().Next(50000, 99999);
            var car = new Car(newCarId, "TestMake", "TestModel", 2023, 850, "available", 5, "1600 cc");

            Assert.DoesNotThrow(() => repo.AddCar(car));

            var result = repo.FindCarById(newCarId);
            Assert.IsNotNull(result);
            Assert.AreEqual(newCarId, result.VehicleID);
            Assert.AreEqual("available", result.Status.Trim());
            repo.RemoveCar(newCarId);
        }

        [Test]
        public void Test_LeaseCreatedSuccessfully()
        {
            int newCarId = new Random().Next(50000, 99999);
            int newCustomerId = new Random().Next(50000, 99999);

            var car = new Car(newCarId, "LeaseMake", "LeaseModel", 2023, 900, "available", 5, "1600 cc");
            repo.AddCar(car);

            var customer = new Customer(newCustomerId, "LeaseFirst", "LeaseLast", "lease@test.com", 9876543210);
            repo.AddCustomer(customer);

            var insertedCar = repo.FindCarById(newCarId);
            Console.WriteLine($"Car Status before lease: {insertedCar.Status}");
            Assert.AreEqual("available", insertedCar.Status.Trim());

            DateTime start = DateTime.Today;
            DateTime end = DateTime.Today.AddDays(5);

            var lease = repo.CreateLease(customer.CustomerID, car.VehicleID, start, end);
            Assert.IsNotNull(lease);
            Assert.AreEqual(customer.CustomerID, lease.CustomerID);
            Assert.AreEqual("DailyLease", lease.Type);

            var updatedCar = repo.FindCarById(newCarId);
            Console.WriteLine($"Car Status after lease: {updatedCar.Status}");
            Assert.AreEqual("notAvailable", updatedCar.Status.Trim());

            repo.ReturnCar(lease.LeaseID);
            repo.RemoveLease(lease.LeaseID);
            repo.RemoveCar(newCarId);
            repo.RemoveCustomer(newCustomerId);
        }

        [Test]
        public void Test_LeaseRetrievedSuccessfully()
        {
            var leases = repo.ListLeaseHistory();
            Assert.IsNotNull(leases);
            Assert.IsTrue(leases.Count >= 0);
        }

        [Test]
        public void Test_ExceptionThrown_ForInvalidIds()
        {
            Assert.Throws<CarNotFoundException>(() => repo.FindCarById(9999999));
            Assert.Throws<CustomerNotFoundException>(() => repo.FindCustomerById(9999999));
            Assert.Throws<LeaseNotFoundException>(() => repo.ReturnCar(9999999));
        }
    }
}
