﻿namespace CarRentalSystem.entity
{
    public class Car
    {
        public int VehicleID { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int DailyRate { get; set; }
        public string Status { get; set; }
        public int PassengerCapacity { get; set; }
        public string EngineCapacity { get; set; }

        public Car() { }

        public Car(int vehicleID, string make, string model, int year, int dailyRate, string status, int passengerCapacity, string engineCapacity)
        {
            VehicleID = vehicleID;
            Make = make;
            Model = model;
            Year = year;
            DailyRate = dailyRate;
            Status = status;
            PassengerCapacity = passengerCapacity;
            EngineCapacity = engineCapacity;
        }
    }
}
