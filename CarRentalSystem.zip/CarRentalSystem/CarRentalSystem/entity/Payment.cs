﻿using System;

namespace CarRentalSystem.entity
{
    public class Payment
    {
        public int PaymentID { get; set; }
        public int LeaseID { get; set; }
        public DateTime PaymentDate { get; set; }
        public int Amount { get; set; }

        public Payment() { }

        public Payment(int paymentID, int leaseID, DateTime paymentDate, int amount)
        {
            PaymentID = paymentID;
            LeaseID = leaseID;
            PaymentDate = paymentDate;
            Amount = amount;
        }
    }
}

