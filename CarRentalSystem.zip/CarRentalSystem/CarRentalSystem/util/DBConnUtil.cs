﻿using Microsoft.Data.SqlClient;

namespace CarRentalSystem.util
{
    public static class DBConnUtil
    {
        private static readonly string connectionString =
            "Server=VIKASH\\MSSQLSERVER1;Database=CAR_RENTAL_SYSTEM;Integrated Security=True;TrustServerCertificate=True";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}


