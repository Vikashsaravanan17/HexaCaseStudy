﻿using System;
using CarRentalSystem.dao;
using CarRentalSystem.entity;
using CarRentalSystem.myexceptions;

namespace CarRentalSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            ICarLeaseRepository repo = new CarLeaseRepositoryImpl();

            while (true)
            {
                Console.WriteLine("\n========== CAR RENTAL SYSTEM ==========");
                Console.WriteLine("1. Add Car");
                Console.WriteLine("2. List Available Cars");
                Console.WriteLine("3. Add Customer");
                Console.WriteLine("4. List Customers");
                Console.WriteLine("5. Create Lease");
                Console.WriteLine("6. Return Car");
                Console.WriteLine("7. List Active Leases");
                Console.WriteLine("8. List Lease History");
                Console.WriteLine("9. Record Payment");
                Console.WriteLine("10. Exit");
                Console.Write("Select an option: ");

                try
                {
                    int choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddCar(repo);
                            break;
                        case 2:
                            ListAvailableCars(repo);
                            break;
                        case 3:
                            AddCustomer(repo);
                            break;
                        case 4:
                            ListCustomers(repo);
                            break;
                        case 5:
                            CreateLease(repo);
                            break;
                        case 6:
                            ReturnCar(repo);
                            break;
                        case 7:
                            ListActiveLeases(repo);
                            break;
                        case 8:
                            ListLeaseHistory(repo);
                            break;
                        case 9:
                            RecordPayment(repo);
                            break;
                        case 10:
                            Console.WriteLine("Exiting...");
                            return;
                        default:
                            Console.WriteLine("Invalid choice, try again.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }

        static void AddCar(ICarLeaseRepository repo)
        {
            Console.Write("Enter Vehicle ID: ");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Make: ");
            string make = Console.ReadLine();
            Console.Write("Model: ");
            string model = Console.ReadLine();
            Console.Write("Year: ");
            int year = Convert.ToInt32(Console.ReadLine());
            Console.Write("Daily Rate: ");
            int rate = Convert.ToInt32(Console.ReadLine());
            Console.Write("Status (available / notAvailable): ");
            string status = Console.ReadLine();
            Console.Write("Passenger Capacity: ");
            int capacity = Convert.ToInt32(Console.ReadLine());
            Console.Write("Engine Capacity: ");
            string engine = Console.ReadLine();

            var car = new Car(id, make, model, year, rate, status, capacity, engine);
            repo.AddCar(car);
            Console.WriteLine("Car added successfully!");
        }

        static void ListAvailableCars(ICarLeaseRepository repo)
        {
            var cars = repo.ListAvailableCars();
            Console.WriteLine("Available Cars:");
            foreach (var car in cars)
            {
                Console.WriteLine($"{car.VehicleID} - {car.Make} {car.Model} ({car.Year}) | {car.EngineCapacity} | Rs.{car.DailyRate}/day");
            }
        }

        static void AddCustomer(ICarLeaseRepository repo)
        {
            Console.Write("Enter Customer ID: ");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.Write("First Name: ");
            string first = Console.ReadLine();
            Console.Write("Last Name: ");
            string last = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            Console.Write("Phone Number: ");
            long phone = Convert.ToInt64(Console.ReadLine());

            var customer = new Customer(id, first, last, email, phone);
            repo.AddCustomer(customer);
            Console.WriteLine("Customer added successfully!");
        }

        static void ListCustomers(ICarLeaseRepository repo)
        {
            var customers = repo.ListCustomers();
            Console.WriteLine("Customers:");
            foreach (var c in customers)
            {
                Console.WriteLine($"{c.CustomerID} - {c.FirstName} {c.LastName}, {c.Email}, {c.PhoneNumber}");
            }
        }

        static void CreateLease(ICarLeaseRepository repo)
        {
            Console.Write("Enter Customer ID: ");
            int custId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Car ID: ");
            int carId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Start Date (yyyy-MM-dd): ");
            DateTime start = DateTime.Parse(Console.ReadLine());
            Console.Write("End Date (yyyy-MM-dd): ");
            DateTime end = DateTime.Parse(Console.ReadLine());

            var lease = repo.CreateLease(custId, carId, start, end);
            Console.WriteLine($"Lease created successfully! Lease ID: {lease.LeaseID}");
        }

        static void ReturnCar(ICarLeaseRepository repo)
        {
            Console.Write("Enter Lease ID to Return Car: ");
            int leaseId = Convert.ToInt32(Console.ReadLine());
            repo.ReturnCar(leaseId);
            Console.WriteLine("Car returned successfully!");
        }

        static void ListActiveLeases(ICarLeaseRepository repo)
        {
            var leases = repo.ListActiveLeases();
            Console.WriteLine("Active Leases:");
            foreach (var l in leases)
            {
                Console.WriteLine($"{l.LeaseID} | Car: {l.VehicleID} | Customer: {l.CustomerID} | From: {l.StartDate.ToShortDateString()} To: {l.EndDate.ToShortDateString()} | {l.Type}");
            }
        }

        static void ListLeaseHistory(ICarLeaseRepository repo)
        {
            var leases = repo.ListLeaseHistory();
            Console.WriteLine("Lease History:");
            foreach (var l in leases)
            {
                Console.WriteLine($"{l.LeaseID} | Car: {l.VehicleID} | Customer: {l.CustomerID} | From: {l.StartDate.ToShortDateString()} To: {l.EndDate.ToShortDateString()} | {l.Type}");
            }
        }

        static void RecordPayment(ICarLeaseRepository repo)
        {
            Console.Write("Enter Lease ID for Payment: ");
            int leaseId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Payment Amount: ");
            int amount = Convert.ToInt32(Console.ReadLine());

            var lease = repo.ListLeaseHistory().Find(l => l.LeaseID == leaseId);
            if (lease == null)
                throw new LeaseNotFoundException($"Lease with ID {leaseId} not found!");

            repo.RecordPayment(lease, amount);
            Console.WriteLine("Payment recorded successfully!");
        }
    }
}

