﻿using System;

namespace CarRentalSystem.myexceptions
{
    public class LeaseNotFoundException : Exception
    {
        public LeaseNotFoundException(string message) : base(message) { }
    }
}

