﻿using System;

namespace CarRentalSystem.myexceptions
{
    public class CarNotFoundException : Exception
    {
        public CarNotFoundException(string message) : base(message) { }
    }
}

