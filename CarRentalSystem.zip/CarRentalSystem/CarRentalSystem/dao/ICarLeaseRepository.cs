﻿using System;
using System.Collections.Generic;
using CarRentalSystem.entity;

namespace CarRentalSystem.dao
{
    public interface ICarLeaseRepository
    {
        void AddCar(Car car);
        void RemoveCar(int carID);
        List<Car> ListAvailableCars();
        List<Car> ListRentedCars();
        Car FindCarById(int carID);

        void AddCustomer(Customer customer);
        void RemoveCustomer(int customerID);
        List<Customer> ListCustomers();
        Customer FindCustomerById(int customerID);

        Lease CreateLease(int customerID, int carID, DateTime startDate, DateTime endDate);
        void ReturnCar(int leaseID);
        List<Lease> ListActiveLeases();
        List<Lease> ListLeaseHistory();
        void RemoveLease(int leaseID);

        void RecordPayment(Lease lease, int amount);
    }
}

