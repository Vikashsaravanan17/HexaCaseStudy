﻿using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using CarRentalSystem.entity;
using CarRentalSystem.util;
using CarRentalSystem.myexceptions;

namespace CarRentalSystem.dao
{
    public class CarLeaseRepositoryImpl : ICarLeaseRepository
    {
        private SqlConnection GetConnection() => DBConnUtil.GetConnection();

        public void AddCar(Car car)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string query = "INSERT INTO Vehicle VALUES (@VehicleID, @Make, @Model, @Year, @DailyRate, @Status, @PassengerCapacity, @EngineCapacity)";
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@VehicleID", car.VehicleID);
                    cmd.Parameters.AddWithValue("@Make", car.Make);
                    cmd.Parameters.AddWithValue("@Model", car.Model);
                    cmd.Parameters.AddWithValue("@Year", car.Year);
                    cmd.Parameters.AddWithValue("@DailyRate", car.DailyRate);
                    cmd.Parameters.AddWithValue("@Status", car.Status.Trim());
                    cmd.Parameters.AddWithValue("@PassengerCapacity", car.PassengerCapacity);
                    cmd.Parameters.AddWithValue("@EngineCapacity", car.EngineCapacity);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void RemoveCar(int carID)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string query = "DELETE FROM Vehicle WHERE vehicleID=@vehicleID";
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@vehicleID", carID);
                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        throw new CarNotFoundException($"Car with ID {carID} not found.");
                }
            }
        }

        public List<Car> ListAvailableCars()
        {
            var cars = new List<Car>();
            using (var con = GetConnection())
            {
                con.Open();
                string query = "SELECT * FROM Vehicle WHERE status='available'";
                using (var cmd = new SqlCommand(query, con))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cars.Add(new Car(
                            (int)reader["vehicleID"],
                            reader["make"].ToString(),
                            reader["model"].ToString(),
                            (int)reader["year"],
                            (int)reader["dailyRate"],
                            reader["status"].ToString(),
                            (int)reader["passengerCapacity"],
                            reader["engineCapacity"].ToString()
                        ));
                    }
                }
            }
            return cars;
        }

        public List<Car> ListRentedCars()
        {
            var cars = new List<Car>();
            using (var con = GetConnection())
            {
                con.Open();
                string query = "SELECT * FROM Vehicle WHERE status='notAvailable'";
                using (var cmd = new SqlCommand(query, con))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cars.Add(new Car(
                            (int)reader["vehicleID"],
                            reader["make"].ToString(),
                            reader["model"].ToString(),
                            (int)reader["year"],
                            (int)reader["dailyRate"],
                            reader["status"].ToString(),
                            (int)reader["passengerCapacity"],
                            reader["engineCapacity"].ToString()
                        ));
                    }
                }
            }
            return cars;
        }

        public Car FindCarById(int carID)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string query = "SELECT * FROM Vehicle WHERE vehicleID=@vehicleID";
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@vehicleID", carID);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Car(
                                (int)reader["vehicleID"],
                                reader["make"].ToString(),
                                reader["model"].ToString(),
                                (int)reader["year"],
                                (int)reader["dailyRate"],
                                reader["status"].ToString(),
                                (int)reader["passengerCapacity"],
                                reader["engineCapacity"].ToString()
                            );
                        }
                        else
                        {
                            throw new CarNotFoundException($"Car with ID {carID} not found.");
                        }
                    }
                }
            }
        }

        public void AddCustomer(Customer customer)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string query = "INSERT INTO Customer VALUES (@CustomerID, @FirstName, @LastName, @Email, @PhoneNumber)";
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@CustomerID", customer.CustomerID);
                    cmd.Parameters.AddWithValue("@FirstName", customer.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", customer.LastName);
                    cmd.Parameters.AddWithValue("@Email", customer.Email);
                    cmd.Parameters.AddWithValue("@PhoneNumber", customer.PhoneNumber);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void RemoveCustomer(int customerID)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string query = "DELETE FROM Customer WHERE customerID=@customerID";
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@customerID", customerID);
                    int rows = cmd.ExecuteNonQuery();
                    if (rows == 0)
                        throw new CustomerNotFoundException($"Customer with ID {customerID} not found.");
                }
            }
        }

        public List<Customer> ListCustomers()
        {
            var customers = new List<Customer>();
            using (var con = GetConnection())
            {
                con.Open();
                string query = "SELECT * FROM Customer";
                using (var cmd = new SqlCommand(query, con))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        customers.Add(new Customer(
                            (int)reader["customerID"],
                            reader["firstName"].ToString(),
                            reader["lastName"].ToString(),
                            reader["email"].ToString(),
                            (long)reader["phoneNumber"]
                        ));
                    }
                }
            }
            return customers;
        }

        public Customer FindCustomerById(int customerID)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string query = "SELECT * FROM Customer WHERE customerID=@customerID";
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@customerID", customerID);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Customer(
                                (int)reader["customerID"],
                                reader["firstName"].ToString(),
                                reader["lastName"].ToString(),
                                reader["email"].ToString(),
                                (long)reader["phoneNumber"]
                            );
                        }
                        else
                        {
                            throw new CustomerNotFoundException($"Customer with ID {customerID} not found.");
                        }
                    }
                }
            }
        }

        public Lease CreateLease(int customerID, int carID, DateTime startDate, DateTime endDate)
        {
            using (var con = GetConnection())
            {
                con.Open();
                var car = FindCarById(carID);
                if (car.Status.Trim() != "available")
                    throw new Exception($"Car with ID {carID} is not available.");
                string leaseType = (endDate.Subtract(startDate).Days > 7) ? "MonthlyLease" : "DailyLease";
                string leaseIdQuery = "SELECT ISNULL(MAX(leaseID), 20) + 1 FROM Lease";
                int newLeaseID;
                using (var cmd = new SqlCommand(leaseIdQuery, con))
                {
                    newLeaseID = (int)cmd.ExecuteScalar();
                }
                string insertLeaseQuery = "INSERT INTO Lease VALUES (@LeaseID, @VehicleID, @CustomerID, @StartDate, @EndDate, @Type)";
                using (var cmd = new SqlCommand(insertLeaseQuery, con))
                {
                    cmd.Parameters.AddWithValue("@LeaseID", newLeaseID);
                    cmd.Parameters.AddWithValue("@VehicleID", carID);
                    cmd.Parameters.AddWithValue("@CustomerID", customerID);
                    cmd.Parameters.AddWithValue("@StartDate", startDate);
                    cmd.Parameters.AddWithValue("@EndDate", endDate);
                    cmd.Parameters.AddWithValue("@Type", leaseType);
                    cmd.ExecuteNonQuery();
                }
                string updateQuery = "UPDATE Vehicle SET status=@status WHERE vehicleID=@vehicleID";
                using (var cmd = new SqlCommand(updateQuery, con))
                {
                    cmd.Parameters.AddWithValue("@status", " notAvailable");
                    cmd.Parameters.AddWithValue("@vehicleID", carID);
                    cmd.ExecuteNonQuery();
                }
                return new Lease(newLeaseID, carID, customerID, startDate, endDate, leaseType);
            }
        }

        public void ReturnCar(int leaseID)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string leaseQuery = "SELECT * FROM Lease WHERE leaseID=@leaseID";
                int carID;
                using (var cmd = new SqlCommand(leaseQuery, con))
                {
                    cmd.Parameters.AddWithValue("@leaseID", leaseID);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read())
                            throw new LeaseNotFoundException($"Lease with ID {leaseID} not found.");
                        carID = (int)reader["vehicleID"];
                    }
                }
                string updateQuery = "UPDATE Vehicle SET status=@status WHERE vehicleID=@vehicleID";
                using (var cmd = new SqlCommand(updateQuery, con))
                {
                    cmd.Parameters.AddWithValue("@status", "available");
                    cmd.Parameters.AddWithValue("@vehicleID", carID);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<Lease> ListActiveLeases()
        {
            var leases = new List<Lease>();
            using (var con = GetConnection())
            {
                con.Open();
                string query = "SELECT * FROM Lease WHERE endDate >= GETDATE()";
                using (var cmd = new SqlCommand(query, con))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        leases.Add(new Lease(
                            (int)reader["leaseID"],
                            (int)reader["vehicleID"],
                            (int)reader["customerID"],
                            (DateTime)reader["startDate"],
                            (DateTime)reader["endDate"],
                            reader["type"].ToString()
                        ));
                    }
                }
            }
            return leases;
        }

        public List<Lease> ListLeaseHistory()
        {
            var leases = new List<Lease>();
            using (var con = GetConnection())
            {
                con.Open();
                string query = "SELECT * FROM Lease";
                using (var cmd = new SqlCommand(query, con))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        leases.Add(new Lease(
                            (int)reader["leaseID"],
                            (int)reader["vehicleID"],
                            (int)reader["customerID"],
                            (DateTime)reader["startDate"],
                            (DateTime)reader["endDate"],
                            reader["type"].ToString()
                        ));
                    }
                }
            }
            return leases;
        }

        public void RecordPayment(Lease lease, int amount)
        {
            using (var con = GetConnection())
            {
                con.Open();
                string paymentIdQuery = "SELECT ISNULL(MAX(paymentID), 100) + 1 FROM Payment";
                int newPaymentID;
                using (var cmd = new SqlCommand(paymentIdQuery, con))
                {
                    newPaymentID = (int)cmd.ExecuteScalar();
                }
                string query = "INSERT INTO Payment VALUES (@PaymentID, @LeaseID, @PaymentDate, @Amount)";
                using (var cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@PaymentID", newPaymentID);
                    cmd.Parameters.AddWithValue("@LeaseID", lease.LeaseID);
                    cmd.Parameters.AddWithValue("@PaymentDate", DateTime.Now);
                    cmd.Parameters.AddWithValue("@Amount", amount);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void RemoveLease(int leaseID)
        {
            using (var con = GetConnection())
            {
                con.Open();
                var cmd = new SqlCommand("DELETE FROM Lease WHERE leaseID=@leaseID", con);
                cmd.Parameters.AddWithValue("@leaseID", leaseID);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
